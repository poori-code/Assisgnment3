import model.Student;
import service.StudentService;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        StudentService service = new StudentService();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Student Course Management System ---");
            System.out.println("1. Add New Student");
            System.out.println("2. Enroll Course for a Student");
            System.out.println("3. View Student by ID");
            System.out.println("4. View All Students");
            System.out.println("5. Remove Student");
            System.out.println("6. Update Student Name");
            System.out.println("7. Remove Course from Student");
            System.out.println("8. Show System Stats");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();  // consume newline
                    System.out.print("Enter Student Name: ");
                    String name = sc.nextLine();
                    if (service.addStudent(id, name))
                        System.out.println("Student added.");
                    else
                        System.out.println("Student ID already exists.");
                    break;

                case 2:
                    System.out.print("Enter Student ID: ");
                    id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Course Name: ");
                    String course = sc.nextLine();
                    if (service.enrollCourse(id, course))
                        System.out.println("Course enrolled.");
                    else
                        System.out.println("Student not found or course already enrolled.");
                    break;

                case 3:
                    System.out.print("Enter Student ID: ");
                    id = sc.nextInt();
                    Student s = service.getStudent(id);
                    if (s != null)
                        System.out.println(s);
                    else
                        System.out.println("Student not found.");
                    break;

                case 4:
                    System.out.println("All Students:");
                    for (Student student : service.getAllStudents()) {
                        System.out.println(student);
                    }
                    break;

                case 5:
                    System.out.print("Enter Student ID to remove: ");
                    id = sc.nextInt();
                    if (service.removeStudent(id))
                        System.out.println("Student removed.");
                    else
                        System.out.println("Student not found.");
                    break;

                case 6:
                    System.out.print("Enter Student ID: ");
                    id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter New Name: ");
                    String newName = sc.nextLine();
                    if (service.updateStudentName(id, newName))
                        System.out.println("Name updated.");
                    else
                        System.out.println("Student not found.");
                    break;

                case 7:
                    System.out.print("Enter Student ID: ");
                    id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Course Name to Remove: ");
                    String courseToRemove = sc.nextLine();
                    if (service.removeCourse(id, courseToRemove))
                        System.out.println("Course removed.");
                    else
                        System.out.println("Student or course not found.");
                    break;

                case 8:
                    System.out.println("Total Students: " + service.getTotalStudents());
                    System.out.println("Total Unique Courses: " + service.getTotalCourses());
                    break;

                case 9:
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 9);

        sc.close();
    }
}
