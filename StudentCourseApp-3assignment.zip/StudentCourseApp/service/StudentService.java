package service;

import model.Student;
import java.util.*;

public class StudentService {
    private Map<Integer, Student> studentMap = new HashMap<>();

    public boolean addStudent(int id, String name) {
        if (studentMap.containsKey(id)) return false;
        studentMap.put(id, new Student(id, name));
        return true;
    }

    public boolean enrollCourse(int id, String course) {
        Student student = studentMap.get(id);
        if (student == null) return false;
        student.addCourse(course);
        return true;
    }

    public Student getStudent(int id) {
        return studentMap.get(id);
    }

    public List<Student> getAllStudents() {
        return new ArrayList<>(studentMap.values());
    }

    public boolean removeStudent(int id) {
        return studentMap.remove(id) != null;
    }

    public boolean updateStudentName(int id, String newName) {
        Student student = studentMap.get(id);
        if (student == null) return false;
        student.setName(newName);
        return true;
    }

    public boolean removeCourse(int id, String course) {
        Student student = studentMap.get(id);
        if (student == null) return false;
        return student.removeCourse(course);
    }

    public int getTotalStudents() {
        return studentMap.size();
    }

    public int getTotalCourses() {
        Set<String> uniqueCourses = new HashSet<>();
        for (Student s : studentMap.values()) {
            uniqueCourses.addAll(s.getCourses());
        }
        return uniqueCourses.size();
    }
}
