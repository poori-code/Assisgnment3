package model;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private int id;
    private String name;
    private List<String> courses;

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
        this.courses = new ArrayList<>();
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public List<String> getCourses() { return courses; }

    public void setName(String name) { this.name = name; }

    public void addCourse(String course) {
        if (!courses.contains(course)) {
            courses.add(course);
        }
    }

    public boolean removeCourse(String course) {
        return courses.remove(course);
    }

    @Override
    public String toString() {
        return "Student ID: " + id + ", Name: " + name + ", Courses: " + courses;
    }
}
